repo: moderntalents/www.moderntalents.com
branch: main

## Last sync

date: 2026-09-08T21:06:19Z

### Updated in this project

- Connected the existing Modern Talents repository as this project's source.
- Read the repo tree only — no repository code was imported or overwritten.
- Design prototype (`Modern Talent Hub App.dc.html`) remains the single deliverable in this project.

## Screen map

| Project screen | Repo files |
| --- | --- |
| Whole prototype (`Modern Talent Hub App.dc.html`) | not yet mapped — prototype was designed before the repo was connected |
| Marketplace / categories | `src/components/` (not yet read) |
| Admin console screens | `src/admin/` (not yet read) |
| Auth, wallet, transactions data | `supabase/migrations/`, `supabase/functions/` (not yet read) |
